"""Agent tool to query check-in agent staffing by zone."""

from pathlib import Path

from langchain_core.tools import tool

from data.py.sql_utils import substitute_schema
from tools.sql_executor import execute_query, format_query_result, get_warehouse, _escape_sql_string

_FUNC_DIR = Path(__file__).resolve().parents[1] / "data" / "func"


@tool
def query_checkin_agent_staffing(zone: str) -> str:
    """Check-in agent staffing: counts how many agents are at counter (ACTIVE) vs away or on break in the given zone. zone: e.g. 'B'."""
    w, wh_id = get_warehouse()
    sql = substitute_schema((_FUNC_DIR / "checkin_agent_staffing.sql").read_text().strip())
    stmt = sql.replace("{zone}", _escape_sql_string(zone))
    try:
        columns, rows = execute_query(w, wh_id, stmt)
        return format_query_result(columns, rows)
    except RuntimeError as e:
        return f"Error: {e}"
